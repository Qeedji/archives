setPref(PrefDomain.App, 'imagePath', "image.ppk");
